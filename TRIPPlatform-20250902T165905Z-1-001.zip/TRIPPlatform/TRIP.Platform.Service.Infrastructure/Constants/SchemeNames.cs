﻿namespace TRIP.Platform.Service.Infrastructure.Constants
{
	public static class SchemeNames
    {
        public const string Common = "dbo";
    }
}
